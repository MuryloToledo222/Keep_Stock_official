// Função de Cadastro do usuário (pega os dados do HTML)

const formCadastro = document.querySelector('#view-cadastro form');

formCadastro.addEventListener('submit', async (e) => {
    e.preventDefault();

    const cpfCru = e.target.cpf.value; 
    
    const cpfApenasNumeros = cpfCru.replace(/\D/g, '');

    const dados = {
        nome: e.target.nome_completo.value,
        email: e.target.email.value,
        cpf: cpfApenasNumeros,
        senha: e.target.senha.value
    };

    console.log("Dados que serão enviados:", dados);

    try {
        const response = await fetch('http://127.0.0.1:5000/cadastrar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            alert(resultado.mensagem);
            switchAuthView('view-login');
        } else {
            // Se o erro vier da API do Invertexto
            alert("Erro no Cadastro: " + (resultado.erro || "Erro desconhecido"));
        }
    } catch (err) {
        alert("Servidor Python offline ou erro de conexão.");
    }
});

async function realizarLogin(e) {
    e.preventDefault();
    
    const dados = {
        email: e.target.email.value,
        senha: e.target.senha.value
    };

    try {
        const response = await fetch('http://127.0.0.1:5000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            alert("Bem-vindo, " + resultado.nome + "!");
            doLogin(); 
        } else {
            alert("Erro no Login: " + resultado.erro);
        }
    } catch (err) {
        alert("Erro ao conectar com o servidor Python.");
    }
}